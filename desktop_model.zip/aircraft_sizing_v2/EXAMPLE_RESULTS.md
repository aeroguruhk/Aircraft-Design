# Tested example results

Illustrative teaching inputs; all four installed engines satisfy their constraint design.

| Example | Gross mass kg | Wing area m² | Span m | W/S Pa | Cruise mission km | Polar range at prescribed speed km |
|---|---:|---:|---:|---:|---:|---:|
| fighter | 7822.46 | 18.72 | 6.12 | 4100 | 800 | 858.7 |
| transport | 39462.76 | 98.01 | 29.70 | 3950 | 2500 | 2500.7 |
| general_aviation | 2303.40 | 22.60 | 13.45 | 1000 | 900 | 936.0 |
| transport_turboprop | 16673.76 | 71.12 | 26.67 | 2300 | 1500 | 1542.1 |

All 12 regression checks passed. Absolute mass closure residuals are below 1e-5 kg.

The examples are numerical demonstrations, not validation against measured aircraft data.

Transport/GA: all six structural components use their own screenshot equations. Fighter gear source verification remains outstanding.
