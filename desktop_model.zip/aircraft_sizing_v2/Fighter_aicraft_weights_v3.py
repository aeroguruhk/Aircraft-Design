"""Compatibility import; the implementation now supports all three categories."""
from aircraft_weights import *
