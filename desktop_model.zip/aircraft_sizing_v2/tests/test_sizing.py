"""Numerical screenshot benchmarks, conservation, unit and infeasibility checks."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import unittest
import numpy as np
from aircraft_weights import Aircraft, category_structure
from Mission_module_SI import Requirements, mission_fuel_fraction
from sizing_solver import AircraftParameters, Atmosphere, SizingSolver, LevelFlightCase, LandingCase, ClimbCase
from SFD_BMD_v2 import sfd_bmd
from run_sizing import load_config, close_detailed_mass, geometry, available_ratio
from perform_v3 import flight_curve

class Correlations(unittest.TestCase):
    def fixture(self,category):
        # Unit-valued US geometry permits independent reduced-equation benchmarks.
        ac=Aircraft(W_dg=1,S_w=1,AR=1,taper=1,sweep=0,tc_root=1,F_w=1,B_h=1,
                    S_ht=1,H_t=1,H_v=1,S_vt=1,M=1,L_t=1,S_r=1,A_vt=1,
                    sweep_vt=0,L=1,D=1,W=1)
        p=AircraftParameters(aircraft_type=category,sweep_ht=0,tc_ht=1,tc_vt=1,
                 AR_ht=1,taper_ht=1,taper_vt=1,L_t_m=.3048,K_y_m=.3048,K_z_m=.3048,
                 S_e_m2=.09290304,S_fuse_wet_m2=.09290304,K_ws=1,
                 N_l=1,L_m_in=1,L_n_in=1,N_nw=1,N_mw=1,N_mss=1,
                 V_stall_landing_m_s=.514444444,wing_fuel_mass_kg=.45359237,
                 q_cruise_pa=47.88025898,W_press_lb=3)
        return ac,p

    def test_transport_six_screenshot_equations(self):
        ac,p=self.fixture('transport')
        got=category_structure(ac,p,Requirements(),1,1,1)
        # Reduced forms of 15.25–30, including HT/elevator and T-tail factors.
        expected=(.0051*2**.1,.0379*2**(-.15),.0026*2**.225,
                  .3280*2**.04,.0106,.032)
        np.testing.assert_allclose(got,expected,rtol=1e-12)

    def test_ga_six_screenshot_equations(self):
        ac,p=self.fixture('general_aviation')
        got=category_structure(ac,p,Requirements(),1,1,1)
        expected=(.036*100**(-.3),.016*100**(-.12),.073*1.2*100**(-.49),
                  .052+3,.095*(1/12)**.409,.125*(1/12)**.845)
        np.testing.assert_allclose(got,expected,rtol=1e-12)

    def test_ga_dynamic_pressure_units_and_exponents(self):
        ac,p=self.fixture('general_aviation')
        one=np.array(category_structure(ac,p,Requirements(),1,1,1))
        p.q_cruise_pa*=4;p.W_press_lb=3
        four=np.array(category_structure(ac,p,Requirements(),1,1,1))
        np.testing.assert_allclose(four[:3]/one[:3],4**np.array([.006,.168,.122]),rtol=1e-12)
        self.assertAlmostEqual((four[3]-3)/(one[3]-3),4**.241)

class Physics(unittest.TestCase):
    def test_range_in_km_not_nm(self):
        m=Requirements(Range=500,Endurance=0,velocity=500,LBYD=10,cruise_ld_factor=1,
                       sfc_cruise=1,takeoff_remaining=1,climb_remaining=1,landing_remaining=1,reserve_multiplier=1)
        self.assertAlmostEqual(mission_fuel_fraction(m),1-np.exp(-.1))

    def test_propeller_bsfc_changes_burn(self):
        m=Requirements(Range=1000,Endurance=0,takeoff_remaining=1,climb_remaining=1,landing_remaining=1,reserve_multiplier=1)
        first=mission_fuel_fraction(m,'turboprop',.8)
        m.bsfc_cruise*=2
        second=mission_fuel_fraction(m,'turboprop',.8)
        self.assertAlmostEqual(1-second,(1-first)**2)

    def test_atmosphere_tropopause(self):
        self.assertAlmostEqual(Atmosphere.get_properties(11000)[0],216.65,places=6)
        self.assertAlmostEqual(Atmosphere.get_properties(15000)[0],216.65,places=6)
        self.assertAlmostEqual(Atmosphere.get_properties(15000)[2],.1937,delta=.0002)

    def test_schrenk_force_and_moment(self):
        r=sfd_bmd(weight=1000,span=10,wing_area=20,taper=1,n=3,safety_factor=1,num_points=5001)
        self.assertAlmostEqual(r['shear_force'][-1],1500,places=8)
        # Half rectangle (centroid at l/2) + half ellipse (centroid 4l/3pi).
        expected=1500*.5*(2.5+20/(3*np.pi))
        self.assertAlmostEqual(r['bending_moment'][-1],expected,delta=.1)
        self.assertEqual(r['shear_force'][0],0)
        self.assertEqual(r['bending_moment'][0],0)

    def test_nan_constraint_is_binding(self):
        p=AircraftParameters();s=SizingSolver(p)
        got=s.get_design_point(np.array([100,200]),{'a':np.array([.2,.3]),'b':np.array([np.nan,.4])})
        self.assertTrue(np.isinf(got[0]));self.assertEqual(got[1],.4)

    def test_constraint_climb_agrees_with_performance(self):
        for propulsion in ('jet','turboprop'):
            p=AircraftParameters(propulsion_type=propulsion,cl_max_clean=1.5)
            case=ClimbCase('climb',3000,roc_m_s=8,beta=.8)
            ws=2000.;ratio=float(case.calculate_tw(np.array([ws]),p)[0])
            _,_,rho,_=Atmosphere.get_properties(3000)
            v=np.sqrt(2*.8*ws/(rho*np.sqrt(p.cd0_sub/p.k_sub)))
            curve=flight_curve(p,p.mass*p.g/ws,3000,ratio,np.array([v]),mass_fraction=.8)
            self.assertAlmostEqual(curve['roc_m_s'][0],8,places=10)

    def test_fixed_mach_landing_can_invalidate(self):
        p=AircraftParameters();case=LandingCase('landing',0,mach=.1,beta=.8)
        result=SizingSolver(p,[case]).get_design_point(np.array([5000]),SizingSolver(p,[case]).solve(np.array([5000])))
        self.assertTrue(np.isinf(result[0]))

    def test_mass_closure_all_examples(self):
        root=Path(__file__).resolve().parents[1]
        for path in (root/'examples').glob('*.json'):
            with self.subTest(example=path.stem):
                cfg,p,m,cases,ws=load_config(path)
                solver=SizingSolver(p,cases);boundary=solver.get_design_point(ws,solver.solve(ws))
                if 'stall_speed_limit_m_s' in cfg.get('design',{}):
                    boundary=np.where(ws<=.5*1.225*cfg['design']['stall_speed_limit_m_s']**2*p.cl_max_clean,boundary,np.inf)
                i=np.argmin(boundary);f=mission_fuel_fraction(m,p.propulsion_type,p.eta_prop)
                mass,weights,_=close_detailed_mass(p,m,ws[i],boundary[i],p.mass,f)
                self.assertAlmostEqual(mass-sum(weights.values())-mass*f-m.useful_mass,0,delta=1e-5)
                self.assertTrue(all(v>0 for v in weights.values()))
                self.assertGreaterEqual(available_ratio(p,mass),boundary[i])

    def test_impossible_mass_closure_raises(self):
        root=Path(__file__).resolve().parents[1]
        _,p,m,_,_=load_config(root/'examples/transport.json')
        p.systems_fraction=.99
        mission_fuel_fraction(m,p.propulsion_type,p.eta_prop)
        with self.assertRaisesRegex(ValueError,'closure'):
            close_detailed_mass(p,m,3000,.3,40000,m.fuel_fraction)

if __name__=='__main__':
    unittest.main()
